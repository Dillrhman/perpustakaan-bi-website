<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Perpustakaan Bina Informatika</title>
  <link rel="stylesheet" href="css/pilih-role.css">
</head>
<body>
  <div class="container">
    <h1>PERPUSTAKAAN<br>BINA INFORMATIKA</h1>
    
    <a href="index1-log-admin.php" class="btn btn-staff">ADMIN</a>
    <a href="index1-log-staff.php" class="btn btn-admin">STAFF</a>
    <a href="index1-log-anggota.php" class="btn btn-anggota">ANGGOTA</a>
  </div>
</body>
</html>
